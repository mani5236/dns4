/* SPDX-License-Identifier: BSD-3-Clause */

#include <rte_common.h>
#include <rte_log.h>

#include "dns_init.h"
#include "dns_cache.h"
#include "dns_classifier.h"

int
dns_system_init(uint32_t socket_id, uint16_t lan_port, uint16_t wan_port,
                uint32_t max_entries)
{
    int rc;

    (void)lan_port;
    (void)wan_port;

    /* Initialize classifier rings and dynfield */
    rc = dns_classifier_init();
    if (rc < 0) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "DNS classifier init failed\n");
        return -1;
    }

    /* Initialize cache */
    rc = dns_cache_init(socket_id, max_entries);
    if (rc < 0) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "DNS cache init failed\n");
        return -1;
    }

    /* TX mempool should be set by the application before use */
    /* g_dns_tx_mempool = rte_pktmbuf_pool_create(...); */

    RTE_LOG(INFO, RTE_LOGTYPE_USER1,
            "DNS cache subsystem initialized: max_entries=%u\n",
            max_entries);
    return 0;
}
