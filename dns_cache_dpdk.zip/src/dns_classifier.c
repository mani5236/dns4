/* SPDX-License-Identifier: BSD-3-Clause */

#include <rte_mbuf.h>
#include <rte_mbuf_dyn.h>
#include <rte_ether.h>
#include <rte_ip.h>
#include <rte_udp.h>
#include <rte_byteorder.h>
#include <rte_log.h>
#include <rte_ring.h>

#include "dns_classifier.h"
#include "dns_parser.h"

struct rte_ring *g_dns_rx_ring = NULL;
struct rte_ring *g_dns_tx_ring = NULL;
struct rte_ring *g_tcp_rx_ring = NULL;
struct rte_ring *g_tcp_tx_ring = NULL;

int g_dns_tx_port_dynfield_offset = -1;

int
dns_classifier_init(void)
{
    const struct rte_mbuf_dynfield dynfield = {
        .name = "dns_tx_port",
        .size = sizeof(uint8_t),
        .align = 1,
    };

    g_dns_tx_port_dynfield_offset = rte_mbuf_dynfield_register(&dynfield);
    if (g_dns_tx_port_dynfield_offset < 0) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "Failed to register dns_tx_port dynfield\n");
        return -1;
    }

    /* Create rings (or they can be created externally and assigned) */
    g_dns_rx_ring = rte_ring_create("dns_rx_ring", 4096, rte_socket_id(),
                                      RING_F_SP_ENQ | RING_F_SC_DEQ);
    g_dns_tx_ring = rte_ring_create("dns_tx_ring", 4096, rte_socket_id(),
                                      RING_F_SP_ENQ | RING_F_SC_DEQ);
    if (!g_dns_rx_ring || !g_dns_tx_ring) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "Failed to create DNS rings\n");
        return -1;
    }

    return 0;
}

void
dns_classifier_dispatch(struct rte_mbuf *m, uint16_t rx_port)
{
    struct rte_ether_hdr *eth;
    struct rte_ipv4_hdr *ip4;
    struct rte_udp_hdr *udp;
    uint16_t eth_type;
    uint16_t dst_port, src_port;
    uint16_t ip_hdr_len;

    eth = rte_pktmbuf_mtod(m, struct rte_ether_hdr *);
    eth_type = rte_be_to_cpu_16(eth->ether_type);

    if (eth_type != RTE_ETHER_TYPE_IPV4)
        goto to_tcp;

    ip4 = (struct rte_ipv4_hdr *)((uint8_t *)eth + sizeof(struct rte_ether_hdr));
    if (ip4->next_proto_id != IPPROTO_UDP)
        goto to_tcp;

    ip_hdr_len = (ip4->version_ihl & 0x0F) * 4;
    udp = (struct rte_udp_hdr *)((uint8_t *)ip4 + ip_hdr_len);

    dst_port = rte_be_to_cpu_16(udp->dst_port);
    src_port = rte_be_to_cpu_16(udp->src_port);

    /* DNS Query from LAN (dst=53) or Response from WAN (src=53) */
    if ((rx_port == LAN_PORT && dst_port == DNS_PORT) ||
        (rx_port == WAN_PORT && src_port == DNS_PORT)) {
        if (rte_ring_enqueue(g_dns_rx_ring, m) < 0) {
            /* Ring full, drop */
            rte_pktmbuf_free(m);
        }
        return;
    }

to_tcp:
    if (g_tcp_rx_ring) {
        if (rte_ring_enqueue(g_tcp_rx_ring, m) < 0)
            rte_pktmbuf_free(m);
    } else {
        /* No TCP ring configured, drop to avoid leak */
        rte_pktmbuf_free(m);
    }
}

void
dns_tx_demux(struct rte_mbuf **pkts, uint16_t nb_pkts)
{
    struct rte_mbuf *lan_pkts[32];
    struct rte_mbuf *wan_pkts[32];
    uint16_t n_lan = 0, n_wan = 0;
    uint16_t i;

    for (i = 0; i < nb_pkts; i++) {
        uint8_t port = *(uint8_t *)rte_mbuf_dynfield(pkts[i],
                        g_dns_tx_port_dynfield_offset, uint8_t *);
        if (port == LAN_PORT)
            lan_pkts[n_lan++] = pkts[i];
        else
            wan_pkts[n_wan++] = pkts[i];
    }

    if (n_lan > 0)
        rte_eth_tx_burst(LAN_PORT, 0, lan_pkts, n_lan);

    if (n_wan > 0)
        rte_eth_tx_burst(WAN_PORT, 0, wan_pkts, n_wan);
}
