/* SPDX-License-Identifier: BSD-3-Clause */

#include <string.h>
#include <stdint.h>
#include <stdio.h>

#include <rte_mbuf.h>
#include <rte_byteorder.h>
#include <rte_memcpy.h>
#include <rte_ether.h>
#include <rte_ip.h>
#include <rte_udp.h>

#include "dns_parser.h"

static inline uint8_t *
dns_get_payload_ptr(struct rte_mbuf *m, uint16_t *payload_len)
{
    struct rte_ether_hdr *eth = rte_pktmbuf_mtod(m, struct rte_ether_hdr *);
    struct rte_ipv4_hdr *ip4 = (struct rte_ipv4_hdr *)((uint8_t *)eth + sizeof(struct rte_ether_hdr));
    uint16_t ip_hdr_len = (ip4->version_ihl & 0x0F) * 4;
    struct rte_udp_hdr *udp = (struct rte_udp_hdr *)((uint8_t *)ip4 + ip_hdr_len);
    uint16_t udp_payload_len = rte_be_to_cpu_16(udp->dgram_len) - sizeof(struct rte_udp_hdr);

    if (payload_len)
        *payload_len = udp_payload_len;

    return (uint8_t *)(udp + 1);
}

int
dns_parse_question(struct rte_mbuf *m, char *name,
                   uint16_t *qtype, uint16_t *qclass)
{
    uint16_t payload_len;
    uint8_t *payload = dns_get_payload_ptr(m, &payload_len);
    uint8_t *p = payload;
    uint16_t remaining = payload_len;
    int name_len = 0;

    if (payload_len < sizeof(struct dns_hdr))
        return -1;

    struct dns_hdr *hdr = (struct dns_hdr *)payload;
    if (rte_be_to_cpu_16(hdr->qdcount) == 0)
        return -1;

    p += sizeof(struct dns_hdr);
    remaining -= sizeof(struct dns_hdr);

    /* Parse QNAME */
    while (remaining > 0) {
        uint8_t len = *p;

        if (len == 0) {
            p++;
            remaining--;
            break;
        }

        /* Compression pointer in question section: skip caching */
        if ((len & 0xC0) == 0xC0) {
            return -1;
        }

        if (remaining < len + 1 || name_len + len + 1 >= DNS_MAX_NAME_LEN)
            return -1;

        if (name_len > 0)
            name[name_len++] = '.';

        memcpy(name + name_len, p + 1, len);
        name_len += len;
        p += len + 1;
        remaining -= len + 1;
    }

    name[name_len] = '\0';

    if (remaining < 4)
        return -1;

    *qtype = rte_be_to_cpu_16(*(uint16_t *)p);
    p += 2;
    *qclass = rte_be_to_cpu_16(*(uint16_t *)p);

    return name_len;
}

uint32_t
dns_extract_min_ttl(struct rte_mbuf *m)
{
    uint16_t payload_len;
    uint8_t *payload = dns_get_payload_ptr(m, &payload_len);
    uint8_t *p;
    uint16_t remaining;
    struct dns_hdr *hdr;
    uint16_t qdcount, ancount;
    uint32_t min_ttl = UINT32_MAX;

    if (payload_len < sizeof(struct dns_hdr))
        return 0;

    hdr = (struct dns_hdr *)payload;
    qdcount = rte_be_to_cpu_16(hdr->qdcount);
    ancount = rte_be_to_cpu_16(hdr->ancount);

    if (ancount == 0)
        return 0;

    p = payload + sizeof(struct dns_hdr);
    remaining = payload_len - sizeof(struct dns_hdr);

    /* Skip question section */
    for (int i = 0; i < qdcount; i++) {
        while (remaining > 0) {
            uint8_t len = *p;
            if (len == 0) {
                p++; remaining--;
                break;
            }
            if ((len & 0xC0) == 0xC0) {
                p += 2; remaining -= 2;
                break;
            }
            p += len + 1; remaining -= len + 1;
        }
        if (remaining < 4) return 0;
        p += 4; remaining -= 4; /* QTYPE + QCLASS */
    }

    /* Walk answer section */
    for (int i = 0; i < ancount; i++) {
        /* Skip name */
        while (remaining > 0) {
            uint8_t len = *p;
            if (len == 0) {
                p++; remaining--;
                break;
            }
            if ((len & 0xC0) == 0xC0) {
                p += 2; remaining -= 2;
                break;
            }
            p += len + 1; remaining -= len + 1;
        }

        if (remaining < 10) break;
        p += 4; remaining -= 4; /* TYPE + CLASS */

        uint32_t ttl = rte_be_to_cpu_32(*(uint32_t *)p);
        if (ttl < min_ttl)
            min_ttl = ttl;
        p += 4; remaining -= 4;

        uint16_t rdlen = rte_be_to_cpu_16(*(uint16_t *)p);
        p += 2 + rdlen; remaining -= 2 + rdlen;
    }

    return (min_ttl == UINT32_MAX) ? 0 : min_ttl;
}

uint16_t
dns_extract_payload(struct rte_mbuf *m, uint8_t *buf, uint16_t buf_len)
{
    uint16_t payload_len;
    uint8_t *payload = dns_get_payload_ptr(m, &payload_len);

    if (payload_len > buf_len)
        payload_len = buf_len;

    /* DNS packets are small; assume contiguous in first segment */
    rte_memcpy(buf, payload, payload_len);
    return payload_len;
}

uint16_t
dns_get_id(struct rte_mbuf *m)
{
    uint16_t payload_len;
    uint8_t *payload = dns_get_payload_ptr(m, &payload_len);
    if (payload_len < 2)
        return 0;
    return rte_be_to_cpu_16(((struct dns_hdr *)payload)->id);
}

void
dns_set_id(uint8_t *payload, uint16_t id)
{
    struct dns_hdr *hdr = (struct dns_hdr *)payload;
    hdr->id = rte_cpu_to_be_16(id);
}

void
dns_set_flags(uint8_t *payload, uint16_t flags)
{
    struct dns_hdr *hdr = (struct dns_hdr *)payload;
    uint16_t cur = rte_be_to_cpu_16(hdr->flags);
    cur |= flags;
    hdr->flags = rte_cpu_to_be_16(cur);
}

void
dns_decrement_ttl(uint8_t *payload, uint16_t payload_len,
                  uint32_t elapsed_sec)
{
    uint8_t *p = payload;
    uint16_t remaining = payload_len;
    struct dns_hdr *hdr;
    uint16_t qdcount, ancount;

    if (remaining < sizeof(struct dns_hdr))
        return;

    hdr = (struct dns_hdr *)p;
    qdcount = rte_be_to_cpu_16(hdr->qdcount);
    ancount = rte_be_to_cpu_16(hdr->ancount);

    p += sizeof(struct dns_hdr);
    remaining -= sizeof(struct dns_hdr);

    /* Skip questions */
    for (int i = 0; i < qdcount; i++) {
        while (remaining > 0) {
            uint8_t len = *p;
            if (len == 0) {
                p++; remaining--;
                break;
            }
            if ((len & 0xC0) == 0xC0) {
                p += 2; remaining -= 2;
                break;
            }
            p += len + 1; remaining -= len + 1;
        }
        if (remaining < 4) return;
        p += 4; remaining -= 4;
    }

    /* Decrement TTLs in answers */
    for (int i = 0; i < ancount; i++) {
        /* Skip name */
        while (remaining > 0) {
            uint8_t len = *p;
            if (len == 0) {
                p++; remaining--;
                break;
            }
            if ((len & 0xC0) == 0xC0) {
                p += 2; remaining -= 2;
                break;
            }
            p += len + 1; remaining -= len + 1;
        }

        if (remaining < 10) break;
        p += 4; remaining -= 4; /* TYPE + CLASS */

        uint32_t ttl = rte_be_to_cpu_32(*(uint32_t *)p);
        if (ttl > elapsed_sec)
            ttl -= elapsed_sec;
        else
            ttl = 0;
        *(uint32_t *)p = rte_cpu_to_be_32(ttl);
        p += 4; remaining -= 4;

        uint16_t rdlen = rte_be_to_cpu_16(*(uint16_t *)p);
        p += 2 + rdlen; remaining -= 2 + rdlen;
    }
}

int
dns_build_key(char *key, const char *name, uint16_t qtype, uint16_t qclass)
{
    size_t len = strlen(name);
    if (len > DNS_MAX_NAME_LEN - 1)
        len = DNS_MAX_NAME_LEN - 1;

    memset(key, 0, DNS_MAX_NAME_LEN + 4);
    memcpy(key, name, len);

    /* Append qtype and qclass in network byte order at fixed offset */
    *(uint16_t *)(key + DNS_MAX_NAME_LEN) = rte_cpu_to_be_16(qtype);
    *(uint16_t *)(key + DNS_MAX_NAME_LEN + 2) = rte_cpu_to_be_16(qclass);

    return DNS_MAX_NAME_LEN + 4;
}

int
dns_copy_swap_headers(struct rte_mbuf *src, struct rte_mbuf *dst)
{
    uint8_t *src_ptr, *dst_ptr;
    struct rte_ether_hdr *eth_s, *eth_d;
    struct rte_ipv4_hdr *ip_s, *ip_d;
    struct rte_udp_hdr *udp_s, *udp_d;
    struct rte_ether_addr tmp_mac;
    uint32_t tmp_ip;
    uint16_t tmp_port;
    uint16_t eth_len = sizeof(struct rte_ether_hdr);
    uint16_t ip_len = sizeof(struct rte_ipv4_hdr);
    uint16_t udp_len = sizeof(struct rte_udp_hdr);

    src_ptr = rte_pktmbuf_mtod(src, uint8_t *);
    dst_ptr = rte_pktmbuf_append(dst, eth_len + ip_len + udp_len);
    if (!dst_ptr)
        return -1;

    rte_memcpy(dst_ptr, src_ptr, eth_len + ip_len + udp_len);

    /* Swap Ethernet */
    eth_s = (struct rte_ether_hdr *)src_ptr;
    eth_d = (struct rte_ether_hdr *)dst_ptr;
    tmp_mac = eth_d->src_addr;
    eth_d->src_addr = eth_d->dst_addr;
    eth_d->dst_addr = tmp_mac;

    /* Swap IPv4 */
    ip_s = (struct rte_ipv4_hdr *)(src_ptr + eth_len);
    ip_d = (struct rte_ipv4_hdr *)(dst_ptr + eth_len);
    tmp_ip = ip_d->src_addr;
    ip_d->src_addr = ip_d->dst_addr;
    ip_d->dst_addr = tmp_ip;

    /* Swap UDP */
    udp_s = (struct rte_udp_hdr *)(src_ptr + eth_len + ip_len);
    udp_d = (struct rte_udp_hdr *)(dst_ptr + eth_len + ip_len);
    tmp_port = udp_d->src_port;
    udp_d->src_port = udp_d->dst_port;
    udp_d->dst_port = tmp_port;

    return 0;
}
