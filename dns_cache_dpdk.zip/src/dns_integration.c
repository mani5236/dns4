/* SPDX-License-Identifier: BSD-3-Clause */

#include <rte_mbuf.h>
#include <rte_ring.h>
#include <rte_log.h>

#include "dns_integration.h"
#include "dns_cache.h"
#include "dns_classifier.h"
#include "dns_parser.h"

void
dns_process_burst(struct rte_mbuf **pkts, uint16_t nb_pkts)
{
    uint16_t i;
    uint16_t tx_count = 0;
    struct rte_mbuf *tx_pkts[DNS_BURST_SIZE];

    for (i = 0; i < nb_pkts; i++) {
        struct rte_mbuf *m = pkts[i];
        uint16_t rx_port = m->port; /* DPDK sets this on RX */

        if (rx_port == LAN_PORT) {
            /* Query from LAN: try cache */
            if (dns_cache_handle_query(m, tx_pkts, &tx_count)) {
                /* Hit: response built, free original query */
                rte_pktmbuf_free(m);
            } else {
                /* Miss: forward to WAN */
                *(uint8_t *)rte_mbuf_dynfield(m, g_dns_tx_port_dynfield_offset,
                                              uint8_t *) = WAN_PORT;
                tx_pkts[tx_count++] = m;
            }
        } else {
            /* Response from WAN: learn and forward to LAN */
            dns_cache_learn(m);
            *(uint8_t *)rte_mbuf_dynfield(m, g_dns_tx_port_dynfield_offset,
                                            uint8_t *) = LAN_PORT;
            tx_pkts[tx_count++] = m;
        }
    }

    /* Enqueue all TX packets back to Core B */
    if (tx_count > 0) {
        uint16_t enq = rte_ring_enqueue_burst(g_dns_tx_ring, (void **)tx_pkts,
                                              tx_count, NULL);
        /* Free any that didn't fit (shouldn't happen with proper sizing) */
        for (i = enq; i < tx_count; i++)
            rte_pktmbuf_free(tx_pkts[i]);
    }
}

uint16_t
dns_lane_poll(void)
{
    struct rte_mbuf *pkts[DNS_BURST_SIZE];
    unsigned nb_rx;

    nb_rx = rte_ring_dequeue_burst(g_dns_rx_ring, (void **)pkts,
                                   DNS_BURST_SIZE, NULL);
    if (nb_rx > 0)
        dns_process_burst(pkts, nb_rx);

    return (uint16_t)nb_rx;
}
