/* SPDX-License-Identifier: BSD-3-Clause */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <rte_hash.h>
#include <rte_hash_crc.h>
#include <rte_mempool.h>
#include <rte_malloc.h>
#include <rte_memcpy.h>
#include <rte_cycles.h>
#include <rte_byteorder.h>
#include <rte_ethdev.h>
#include <rte_log.h>

#include "dns_cache.h"
#include "dns_parser.h"
#include "dns_classifier.h"

struct dns_cache g_dns_cache;
struct dns_cache_stats g_dns_cache_stats;
struct rte_mempool *g_dns_tx_mempool = NULL;

static inline uint32_t
dns_get_elapsed_sec(uint64_t tsc_inserted)
{
    uint64_t now = rte_rdtsc();
    uint64_t hz = rte_get_tsc_hz();
    return (uint32_t)((now - tsc_inserted) / hz);
}

int
dns_cache_init(uint32_t socket_id, uint32_t max_entries)
{
    memset(&g_dns_cache, 0, sizeof(g_dns_cache));
    g_dns_cache.max_entries = max_entries;

    char name[RTE_HASH_NAMESIZE];

    /* Create hash table */
    struct rte_hash_parameters hash_params = {
        .name = "dns_cache_hash",
        .entries = max_entries,
        .key_len = DNS_MAX_NAME_LEN + 4,
        .hash_func = rte_hash_crc,
        .hash_func_init_val = 0,
        .socket_id = (int)socket_id,
        .extra_flag = RTE_HASH_EXTRA_FLAGS_NO_FREE_ON_DEL,
    };
    g_dns_cache.ht = rte_hash_create(&hash_params);
    if (!g_dns_cache.ht) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "Failed to create DNS cache hash table\n");
        return -1;
    }

    /* Entry pool */
    snprintf(name, sizeof(name), "dns_entry_pool");
    g_dns_cache.entry_pool = rte_mempool_create(name,
            max_entries,
            sizeof(struct dns_cache_entry),
            0, 0,
            NULL, NULL,
            NULL, NULL,
            (int)socket_id, 0);
    if (!g_dns_cache.entry_pool) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "Failed to create DNS entry pool\n");
        rte_hash_free(g_dns_cache.ht);
        return -1;
    }

    /* Data pool (payload buffers) */
    snprintf(name, sizeof(name), "dns_data_pool");
    g_dns_cache.data_pool = rte_mempool_create(name,
            max_entries,
            DNS_MAX_PAYLOAD,
            0, 0,
            NULL, NULL,
            NULL, NULL,
            (int)socket_id, 0);
    if (!g_dns_cache.data_pool) {
        RTE_LOG(ERR, RTE_LOGTYPE_USER1, "Failed to create DNS data pool\n");
        rte_mempool_free(g_dns_cache.entry_pool);
        rte_hash_free(g_dns_cache.ht);
        return -1;
    }

    TAILQ_INIT(&g_dns_cache.lru);
    return 0;
}

void
dns_cache_destroy(void)
{
    struct dns_cache_entry *e, *tmp;

    if (g_dns_cache.ht) {
        TAILQ_FOREACH_SAFE(e, &g_dns_cache.lru, lru, tmp) {
            dns_cache_evict(e);
        }
        rte_hash_free(g_dns_cache.ht);
        g_dns_cache.ht = NULL;
    }

    if (g_dns_cache.entry_pool) {
        rte_mempool_free(g_dns_cache.entry_pool);
        g_dns_cache.entry_pool = NULL;
    }

    if (g_dns_cache.data_pool) {
        rte_mempool_free(g_dns_cache.data_pool);
        g_dns_cache.data_pool = NULL;
    }
}

void
dns_cache_evict(struct dns_cache_entry *entry)
{
    char key[DNS_MAX_NAME_LEN + 4];

    if (!entry) return;

    dns_build_key(key, entry->name, entry->qtype, entry->qclass);
    rte_hash_del_key(g_dns_cache.ht, key);

    TAILQ_REMOVE(&g_dns_cache.lru, entry, lru);
    g_dns_cache.count--;
    g_dns_cache_stats.evicted++;

    if (entry->payload)
        rte_mempool_put(g_dns_cache.data_pool, entry->payload);
    rte_mempool_put(g_dns_cache.entry_pool, entry);
}

int
dns_cache_handle_query(struct rte_mbuf *query,
                         struct rte_mbuf **tx_pkts,
                         uint16_t *tx_count)
{
    char name[DNS_MAX_NAME_LEN];
    uint16_t qtype, qclass;
    struct dns_cache_entry *entry;
    char key[DNS_MAX_NAME_LEN + 4];
    int rc;

    rc = dns_parse_question(query, name, &qtype, &qclass);
    if (rc < 0) {
        g_dns_cache_stats.errors++;
        return 0; /* Malformed, treat as miss */
    }

    dns_build_key(key, name, qtype, qclass);

    rc = rte_hash_lookup_data(g_dns_cache.ht, key, (void **)&entry);
    if (rc < 0) {
        g_dns_cache_stats.misses++;
        return 0; /* Miss */
    }

    /* Check TTL expiration (lazy) */
    uint32_t elapsed = dns_get_elapsed_sec(entry->tsc_inserted);
    if (elapsed >= entry->ttl_sec) {
        g_dns_cache_stats.expired++;
        dns_cache_evict(entry);
        return 0; /* Expired, treat as miss */
    }

    /* Cache hit: build response */
    struct rte_mbuf *rsp = dns_build_response(query, entry, elapsed);
    if (!rsp) {
        g_dns_cache_stats.errors++;
        return 0; /* OOM, fall back to miss */
    }

    /* Mark for LAN TX */
    *(uint8_t *)rte_mbuf_dynfield(rsp, g_dns_tx_port_dynfield_offset, uint8_t *) = LAN_PORT;

    tx_pkts[(*tx_count)++] = rsp;
    g_dns_cache_stats.hits++;
    return 1;
}

void
dns_cache_learn(struct rte_mbuf *response)
{
    char name[DNS_MAX_NAME_LEN];
    uint16_t qtype, qclass;
    uint32_t ttl;
    struct dns_cache_entry *entry;
    char key[DNS_MAX_NAME_LEN + 4];
    int key_len, rc;

    rc = dns_parse_question(response, name, &qtype, &qclass);
    if (rc < 0) {
        g_dns_cache_stats.errors++;
        return;
    }

    ttl = dns_extract_min_ttl(response);
    if (ttl == 0)
        return; /* Don't cache zero TTL */

    /* Check if already exists (update) */
    key_len = dns_build_key(key, name, qtype, qclass);
    rc = rte_hash_lookup_data(g_dns_cache.ht, key, (void **)&entry);
    if (rc >= 0) {
        /* Update existing entry */
        uint16_t new_len = dns_extract_payload(response, entry->payload, DNS_MAX_PAYLOAD);
        entry->payload_len = new_len;
        entry->tsc_inserted = rte_rdtsc();
        entry->ttl_sec = ttl;
        /* Move to LRU head */
        TAILQ_REMOVE(&g_dns_cache.lru, entry, lru);
        TAILQ_INSERT_HEAD(&g_dns_cache.lru, entry, lru);
        g_dns_cache_stats.learned++;
        return;
    }

    /* Evict if full */
    if (g_dns_cache.count >= g_dns_cache.max_entries) {
        struct dns_cache_entry *victim = TAILQ_LAST(&g_dns_cache.lru, dns_lru_head);
        if (victim)
            dns_cache_evict(victim);
    }

    /* Allocate new entry */
    if (rte_mempool_get(g_dns_cache.entry_pool, (void **)&entry) < 0) {
        g_dns_cache_stats.errors++;
        return;
    }

    if (rte_mempool_get(g_dns_cache.data_pool, (void **)&entry->payload) < 0) {
        rte_mempool_put(g_dns_cache.entry_pool, entry);
        g_dns_cache_stats.errors++;
        return;
    }

    strncpy(entry->name, name, DNS_MAX_NAME_LEN - 1);
    entry->name[DNS_MAX_NAME_LEN - 1] = '\0';
    entry->qtype = qtype;
    entry->qclass = qclass;
    entry->tsc_inserted = rte_rdtsc();
    entry->ttl_sec = ttl;
    entry->payload_len = dns_extract_payload(response, entry->payload, DNS_MAX_PAYLOAD);

    rc = rte_hash_add_key_data(g_dns_cache.ht, key, entry);
    if (rc < 0) {
        rte_mempool_put(g_dns_cache.data_pool, entry->payload);
        rte_mempool_put(g_dns_cache.entry_pool, entry);
        g_dns_cache_stats.errors++;
        return;
    }

    TAILQ_INSERT_HEAD(&g_dns_cache.lru, entry, lru);
    g_dns_cache.count++;
    g_dns_cache_stats.learned++;
}

struct rte_mbuf *
dns_build_response(struct rte_mbuf *query,
                   struct dns_cache_entry *entry,
                   uint32_t elapsed_sec)
{
    struct rte_mbuf *rsp;
    uint8_t *rsp_ptr, *dns_ptr;
    uint16_t eth_len, ip_len, udp_len, total_len;
    uint16_t query_id;
    struct rte_ether_hdr *eth_q, *eth_r;
    struct rte_ipv4_hdr *ip_q, *ip_r;
    struct rte_udp_hdr *udp_q, *udp_r;
    struct rte_ether_addr tmp_mac;
    uint32_t tmp_ip;
    uint16_t tmp_port;
    struct rte_mempool *pool;

    pool = g_dns_tx_mempool ? g_dns_tx_mempool : query->pool;
    rsp = rte_pktmbuf_alloc(pool);
    if (!rsp)
        return NULL;

    eth_len = sizeof(struct rte_ether_hdr);
    ip_len = sizeof(struct rte_ipv4_hdr); /* Assumes no IP options for DNS */
    udp_len = sizeof(struct rte_udp_hdr);

    total_len = eth_len + ip_len + udp_len + entry->payload_len;
    rsp_ptr = rte_pktmbuf_append(rsp, total_len);
    if (!rsp_ptr) {
        rte_pktmbuf_free(rsp);
        return NULL;
    }

    /* Copy headers from query */
    eth_q = rte_pktmbuf_mtod(query, struct rte_ether_hdr *);
    eth_r = (struct rte_ether_hdr *)rsp_ptr;
    rte_memcpy(eth_r, eth_q, eth_len + ip_len + udp_len);

    /* Swap Ethernet addresses */
    tmp_mac = eth_r->src_addr;
    eth_r->src_addr = eth_r->dst_addr;
    eth_r->dst_addr = tmp_mac;

    /* Swap IPv4 addresses */
    ip_q = (struct rte_ipv4_hdr *)((uint8_t *)eth_q + eth_len);
    ip_r = (struct rte_ipv4_hdr *)((uint8_t *)eth_r + eth_len);
    tmp_ip = ip_r->src_addr;
    ip_r->src_addr = ip_r->dst_addr;
    ip_r->dst_addr = tmp_ip;

    /* Update IP total length */
    ip_r->total_length = rte_cpu_to_be_16(ip_len + udp_len + entry->payload_len);

    /* Swap UDP ports */
    udp_q = (struct rte_udp_hdr *)((uint8_t *)ip_q + ip_len);
    udp_r = (struct rte_udp_hdr *)((uint8_t *)ip_r + ip_len);
    tmp_port = udp_r->src_port;
    udp_r->src_port = udp_r->dst_port;
    udp_r->dst_port = tmp_port;

    /* Update UDP length */
    udp_r->dgram_len = rte_cpu_to_be_16(udp_len + entry->payload_len);

    /* Copy DNS payload */
    dns_ptr = rsp_ptr + eth_len + ip_len + udp_len;
    rte_memcpy(dns_ptr, entry->payload, entry->payload_len);

    /* Patch DNS ID from query */
    query_id = dns_get_id(query);
    dns_set_id(dns_ptr, query_id);

    /* Set response flags: QR=1, AA=1, RA=1 */
    dns_set_flags(dns_ptr, DNS_FLAG_QR | DNS_FLAG_AA | DNS_FLAG_RA);

    /* Decrement TTLs if needed */
    if (elapsed_sec > 0)
        dns_decrement_ttl(dns_ptr, entry->payload_len, elapsed_sec);

    /* Setup mbuf metadata for hardware checksum offload */
    rsp->l2_len = eth_len;
    rsp->l3_len = ip_len;
    rsp->ol_flags = PKT_TX_IPV4 | PKT_TX_IP_CKSUM | PKT_TX_UDP_CKSUM;
    udp_r->dgram_cksum = rte_ipv4_phdr_cksum(ip_r, rsp->ol_flags);

    rsp->data_len = total_len;
    rsp->pkt_len = total_len;

    return rsp;
}
