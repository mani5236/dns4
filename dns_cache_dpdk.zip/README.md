# DPDK UDP DNS Cache Module

Deployment-ready single-level DNS cache for DPDK-based WAN optimizers.

## Architecture

- **Core B (I/O Core)**: RX/TX, packet classification, ring dispatch
- **Core A (Stateful Core)**: TCP/ROHC/Coalescing + DNS bypass lane
- **Zero locks**: Single-core cache ownership on Core A
- **UDP port 53 only**: Queries (LAN dst=53) and Responses (WAN src=53)

## Files

| File | Description |
|------|-------------|
| `include/dns_cache.h` | Hash table + LRU cache, response building |
| `include/dns_parser.h` | DNS wire-format parsing, TTL extraction |
| `include/dns_classifier.h` | Core B classification and TX demux |
| `include/dns_integration.h` | Core A bypass lane integration |
| `include/dns_init.h` | System initialization |
| `src/dns_cache.c` | Cache implementation |
| `src/dns_parser.c` | DNS parser implementation |
| `src/dns_classifier.c` | Classifier and TX demux |
| `src/dns_integration.c` | Core A integration |
| `src/dns_init.c` | Initialization |
| `Makefile` | Build rules |

## Integration

### 1. Initialize in your main()

```c
#include "dns_init.h"

/* After DPDK EAL init, before worker cores start */
if (dns_system_init(rte_socket_id(), LAN_PORT, WAN_PORT, 16384) < 0)
    rte_exit(EXIT_FAILURE, "DNS init failed");

/* Set TX mempool (optional, falls back to RX pool) */
extern struct rte_mempool *g_dns_tx_mempool;
g_dns_tx_mempool = tx_pktmbuf_pool;
```

### 2. Core B RX Loop (I/O Core)

```c
#include "dns_classifier.h"

while (1) {
    uint16_t nb_rx = rte_eth_rx_burst(port, queue, pkts, 32);
    for (i = 0; i < nb_rx; i++) {
        dns_classifier_dispatch(pkts[i], port);
    }

    /* TX from DNS lane */
    uint16_t nb_dns_tx = rte_ring_dequeue_burst(g_dns_tx_ring, (void **)pkts, 32, NULL);
    if (nb_dns_tx > 0)
        dns_tx_demux(pkts, nb_dns_tx);

    /* TX from TCP lane (your existing code) */
    ...
}
```

### 3. Core A Main Loop (TCP/ROHC/Coalescing Core)

```c
#include "dns_integration.h"

while (1) {
    /* Your existing heavy processing */
    process_tcp_sessions();
    process_rohc_compress();
    process_coalescing();

    /* DNS bypass lane (cheap, isolated) */
    dns_lane_poll();
}
```

### 4. Stats (optional)

```c
#include "dns_cache.h"
extern struct dns_cache_stats g_dns_cache_stats;

printf("DNS hits=%"PRIu64" misses=%"PRIu64" learned=%"PRIu64"\n",
       g_dns_cache_stats.hits,
       g_dns_cache_stats.misses,
       g_dns_cache_stats.learned);
```

## Build

Requires DPDK >= 20.11 (for `rte_mbuf_dynfield_register`).

```bash
make
```

Link `libdns_cache.a` into your DPDK application.

## Tuning

- `DNS_CACHE_ENTRIES`: Number of cached entries (default 16384)
- `DNS_MAX_PAYLOAD`: Max cached DNS payload (default 4096 for EDNS0)
- Ring sizes: 4096 entries each (adjust in `dns_classifier.c`)
- `DNS_BURST_SIZE`: 32 (adjust based on your traffic profile)

## Notes

- TCP DNS (port 53 over TCP) is NOT cached and goes through the TCP lane.
- DNS names with compression pointers in the question section are skipped.
- Negative caching (NXDOMAIN) is supported if the response contains a valid SOA minimum TTL.
- IP/UDP checksums are offloaded to hardware via `PKT_TX_IP_CKSUM | PKT_TX_UDP_CKSUM`.
- If your NIC does not support checksum offload, compute software checksums in `dns_build_response()`.
- The cache assumes IPv4 with no IP options. If you need IP options support, modify `dns_build_response()` to read `ip_hdr_len` dynamically.
