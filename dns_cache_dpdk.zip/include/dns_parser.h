/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef DNS_PARSER_H
#define DNS_PARSER_H

#include <stdint.h>
#include <rte_mbuf.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DNS_PORT                53
#define DNS_MAX_NAME_LEN        256
#define DNS_MAX_PAYLOAD         4096

#define DNS_FLAG_QR             0x8000
#define DNS_FLAG_AA             0x0400
#define DNS_FLAG_RA             0x0080

struct dns_hdr {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} __rte_packed;

/* Parse DNS question from mbuf. Returns name length or -1 on error */
int dns_parse_question(struct rte_mbuf *m, char *name,
                       uint16_t *qtype, uint16_t *qclass);

/* Extract minimum TTL from answer section. Returns 0 if no answers */
uint32_t dns_extract_min_ttl(struct rte_mbuf *m);

/* Extract DNS payload (UDP payload) into buffer. Returns copied length */
uint16_t dns_extract_payload(struct rte_mbuf *m, uint8_t *buf, uint16_t buf_len);

/* Get DNS ID from mbuf query */
uint16_t dns_get_id(struct rte_mbuf *m);

/* Set DNS ID in payload buffer */
void dns_set_id(uint8_t *payload, uint16_t id);

/* Set DNS flags in payload buffer */
void dns_set_flags(uint8_t *payload, uint16_t flags);

/* Decrement TTLs in answer RRs by elapsed seconds */
void dns_decrement_ttl(uint8_t *payload, uint16_t payload_len,
                       uint32_t elapsed_sec);

/* Build fixed-size hash key from name+qtype+qclass. Returns key length */
int dns_build_key(char *key, const char *name, uint16_t qtype, uint16_t qclass);

/* Copy L2/L3/L4 headers from src to dst, swap src/dst addresses */
int dns_copy_swap_headers(struct rte_mbuf *src, struct rte_mbuf *dst);

#ifdef __cplusplus
}
#endif

#endif /* DNS_PARSER_H */
