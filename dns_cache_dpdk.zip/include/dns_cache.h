/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef DNS_CACHE_H
#define DNS_CACHE_H

#include <stdint.h>
#include <rte_mbuf.h>
#include <rte_hash.h>
#include <rte_mempool.h>
#include <sys/queue.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DNS_CACHE_ENTRIES       16384
#define DNS_CACHE_DATA_SIZE     DNS_MAX_PAYLOAD

struct dns_cache_entry {
    char        name[DNS_MAX_NAME_LEN];
    uint16_t    qtype;
    uint16_t    qclass;
    uint64_t    tsc_inserted;
    uint32_t    ttl_sec;
    uint16_t    payload_len;
    uint8_t    *payload;
    TAILQ_ENTRY(dns_cache_entry) lru;
};

struct dns_cache {
    struct rte_hash        *ht;
    struct rte_mempool     *entry_pool;
    struct rte_mempool     *data_pool;
    TAILQ_HEAD(dns_lru_head, dns_cache_entry) lru;
    uint32_t                count;
    uint32_t                max_entries;
};

struct dns_cache_stats {
    uint64_t hits;
    uint64_t misses;
    uint64_t learned;
    uint64_t expired;
    uint64_t evicted;
    uint64_t errors;
};

extern struct dns_cache g_dns_cache;
extern struct dns_cache_stats g_dns_cache_stats;
extern struct rte_mempool *g_dns_tx_mempool;

int dns_cache_init(uint32_t socket_id, uint32_t max_entries);
void dns_cache_destroy(void);

/* Returns 1 on cache hit (reply built), 0 on miss */
int dns_cache_handle_query(struct rte_mbuf *query,
                           struct rte_mbuf **tx_pkts,
                           uint16_t *tx_count);

/* Learn from WAN response */
void dns_cache_learn(struct rte_mbuf *response);

/* Evict and free entry */
void dns_cache_evict(struct dns_cache_entry *entry);

/* Build response mbuf from cached entry */
struct rte_mbuf *dns_build_response(struct rte_mbuf *query,
                                    struct dns_cache_entry *entry,
                                    uint32_t elapsed_sec);

#ifdef __cplusplus
}
#endif

#endif /* DNS_CACHE_H */
