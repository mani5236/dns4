/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef DNS_INTEGRATION_H
#define DNS_INTEGRATION_H

#include <rte_mbuf.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DNS_BURST_SIZE  32

/* Process a burst of DNS packets (called on Core A) */
void dns_process_burst(struct rte_mbuf **pkts, uint16_t nb_pkts);

/* Poll DNS ring and process (wrapper for Core A main loop) */
uint16_t dns_lane_poll(void);

#ifdef __cplusplus
}
#endif

#endif /* DNS_INTEGRATION_H */
