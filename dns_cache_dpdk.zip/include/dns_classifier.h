/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef DNS_CLASSIFIER_H
#define DNS_CLASSIFIER_H

#include <rte_mbuf.h>
#include <rte_ring.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LAN_PORT    0
#define WAN_PORT    1

/* Rings connecting I/O core (Core B) and Stateful core (Core A) */
extern struct rte_ring *g_dns_rx_ring;  /* Core B -> Core A (DNS packets) */
extern struct rte_ring *g_dns_tx_ring;  /* Core A -> Core B (DNS replies/forward) */
extern struct rte_ring *g_tcp_rx_ring;  /* Core B -> Core A (TCP/Other) */
extern struct rte_ring *g_tcp_tx_ring;  /* Core A -> Core B (TCP/Other) */

/* Dynamic mbuf field offset for TX port selection */
extern int g_dns_tx_port_dynfield_offset;

/* Register dynamic field and create rings */
int dns_classifier_init(void);

/* Core B: Classify and dispatch mbuf to appropriate ring */
void dns_classifier_dispatch(struct rte_mbuf *m, uint16_t rx_port);

/* Core B: Demux TX packets from Core A to correct port */
void dns_tx_demux(struct rte_mbuf **pkts, uint16_t nb_pkts);

#ifdef __cplusplus
}
#endif

#endif /* DNS_CLASSIFIER_H */
