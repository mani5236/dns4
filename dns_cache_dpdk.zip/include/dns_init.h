/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef DNS_INIT_H
#define DNS_INIT_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Initialize entire DNS subsystem */
int dns_system_init(uint32_t socket_id, uint16_t lan_port, uint16_t wan_port,
                    uint32_t max_entries);

#ifdef __cplusplus
}
#endif

#endif /* DNS_INIT_H */
